var mongoose = require('mongoose');

//Set up default mongoose connection
mongoose.connect('mongodb+srv://root:root@cluster0-tbodi.mongodb.net/test?retryWrites=true&w=majority',function(){console.log('Db connected !!!')})
//Get the default connection
var db = mongoose.connection;

//Bind connection to error event (to get notification of connection errors)
db.on('error', console.error.bind(console, 'MongoDB connection error:'));
var todoschema =new mongoose.Schema({
    item:String
});
var Todo=mongoose.model('Todo',todoschema)