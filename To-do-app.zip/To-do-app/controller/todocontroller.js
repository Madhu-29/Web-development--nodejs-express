var bodyParser=require('body-parser');
var mongoose=require('mongoose');
mongoose.connect('mongodb+srv://namelist:madhu@cluster0-m32v7.mongodb.net/test?retryWrites=true&w=majority',{useNewUrlParser: true } ,function(){console.log('Db connected!!!')});

//creating  a schema
var todoschema =new mongoose.Schema({
    item:String
});

var Todo=mongoose.model('namelist',todoschema)
// var itemOne =Todo({item:'buy Sweets'}).save(function(err){
//     if(err) throw err;
//
//     console.log('item saved');
// });;
//var data=[{item:'Walk'},{item:'Eat'}];
var urlencodedParser = bodyParser.urlencoded({ extended: false });
module.exports=function(app){
    app.get('/namelist',function(req,res){
        Todo.find({},function(err,data){
            if (err) throw err;
            res.render('todo',{todoes:data});
        });
    });
    app.post('/namelist', urlencodedParser,function(req,res){
        var newTodo =Todo(req.body).save(function(err,data){
            if (err) throw err;
            res.json(data);
        });
    });
    app.delete('/namelist/:item',function(req,res){
        Todo.find({item: req.params.item.replace(/\-/g, ' ')}).deleteOne(function(err, data){
            if (err) throw err;

            res.json({todoes:data});

        });


    });
};